from urllib.request import urlopen as uReq
from bs4 import BeautifulSoup as soup
import pandas as pd

# Url to get our results
url_2022 = "https://www.syracuse.com/orangebasketball/2022/04/march-madness-2022-final-ncaa-tournament-bracket-results.html"
uClient_2022 = uReq(url_2022)
page_html_2022 = uClient_2022.read()
uClient_2022.close()
page_soup_cbs = soup(page_html_2022, "html.parser")
cells = page_soup_cbs.findAll(
    "p", {"class": "article__paragraph article__paragraph--left"})

# For later
s = set({})

# Thankfully it starts with winner first, so we can take a shortcut
seeds = []
teams = []
scores = []
rounds = []

for i in range(len(cells)):
    # If text gives round description
    if "No." not in cells[i].text:
        if "First Four" in cells[i].text:
            round = 0
        elif "First Round" in cells[i].text:
            round = 1
        elif "Second Round" in cells[i].text:
            round = 2
        elif "Sweet 16" in cells[i].text:
            round = 3
        elif "Elite Eight" in cells[i].text:
            round = 4
        elif "Final Four" in cells[i].text:
            round = 5
    # Game Data
    else:
        x = cells[i].text.split()
        seed1 = x[1]
        team1 = x[2]
        # If game went to OT, then the list would be altered slightly
        if x[-1] == "(OT)":
            z = 1
        else:
            z = 0
        for j in range(3, len(x)):
            if x[j][:len(x[j]) - 1].isnumeric():
                score1 = x[j][:len(x[j]) - 1]
                seed2 = x[j + 2]
                for k in range(3, j):
                    team1 = team1 + " " + x[k]
                team2 = x[j + 3]
                for l in range(j + 4, len(x) - 1 - z):
                    team2 = team2 + " " + x[l]
                break
        score2 = x[-1 - z]

        # For later
        s.add(team1)
        s.add(team2)

        # Append data to lists
        seeds.append((seed1, seed2))
        teams.append([team1, team2])
        scores.append((score1, score2))
        rounds.append(round)

# We need to keep the names consistent with the cleaned file
with open("march_madness_results.csv", "r") as file:
    lines = [line for line in file]

# Add all names that participated in March Madness
set_of_names = set({})
for m in lines:
    names = m.split(",")
    set_of_names.add(names[3])
    set_of_names.add(names[-2])

# Look at all the mismatched names or newcomers
for n in s:
    if n not in set_of_names:
        print(n)

# Ctrl + F (cmd + F for Mac) these names
'''
Fullerton (Renamed to 'Cal State Fullerton')
Bryant (First time in the Big Dance)
UConn (Renamed to 'Connecticut')
Murray State (Renamed to 'Murray St.')
No. 7 Southern California (This was acutally a mistake on the webpage. It repeated No. 7, so we just say 'Southern California')
Saint Mary’s (CA) (Renamed to 'St. Mary's (Cal.)')
UAB (Renamed to 'Alabama-Birmingham')
Saint Peter’s (Renamed to 'St. Peter's')
Saint Mary’s (Renamed to 'St. Mary's (Cal.)')
Longwood (Also first time in the Big Dance)
Loyola Chicago (Renamed to 'Loyola (Ill.)')     
'''

# Finally we add to our data while renaming appropiately
with open("march_madness_results.csv", "a") as file:
    # Go through the checks first
    for o in range(len(scores)):
        if teams[o][0] == "Fullerton":
            teams[o][0] = 'Cal State Fullerton'
        elif teams[o][1] == "Fullerton":
            teams[o][1] = 'Cal State Fullerton'
        elif teams[o][0] == "UConn":
            teams[o][0] = 'Connecticut'
        elif teams[o][1] == "UConn":
            teams[o][1] = 'Connecticut'
        elif teams[o][0] == "Murray State":
            teams[o][0] = 'Murray St.'
        elif teams[o][1] == "Murray State":
            teams[o][1] = 'Murray St.'
        elif teams[o][0] == "No. 7 Southern California":
            teams[o][0] = 'Southern California'
        elif teams[o][1] == "No. 7 Southern California":
            teams[o][1] = 'Southern California'
        elif teams[o][0] == "Saint Mary’s (CA)" or teams[o][0] == "Saint Mary’s":
            teams[o][0] = "St. Mary's (Cal.)"
        elif teams[o][1] == "Saint Mary’s (CA)" or teams[o][1] == "Saint Mary’s":
            teams[o][1] = "St. Mary's (Cal.)"
        elif teams[o][0] == "UAB":
            teams[o][0] = 'Alabama-Birmingham'
        elif teams[o][1] == "UAB":
            teams[o][1] = 'Alabama-Birmingham'
        elif teams[o][0] == "Saint Peter’s":
            teams[o][0] = "St. Peter's"
        elif teams[o][1] == "Saint Peter’s":
            teams[o][1] = "St. Peter's"
        elif teams[o][0] == "Loyola Chicago":
            teams[o][0] = 'Loyola (Ill.)'
        elif teams[o][1] == "Loyola Chicago":
            teams[o][1] = 'Loyola (Ill.)'

        # Finally write it into the file
        file.write(
            F"2022,{rounds[o]},{seeds[o][0]},{teams[o][0]},{scores[o][0]},{seeds[o][1]},{teams[o][1]},{scores[o][1]} \n")

    # Unfortunately, this webpage does not have the results of the
    # championship game, so we will have to write it down manually
    file.write("2022,6,1,Kansas,72,8,North Carolina,69\n")


# A quick test to see if it worked
df = pd.read_csv("march_madness_results.csv")
df_2022 = df[df["YEAR"] == 2022]
df_not_2022 = df[df["YEAR"] != 2022]

# List of name changes
w = ["Cal State Fullerton", "Bryant", "Connecticut", "Murray St.", "Southern California",
     "St. Mary's (Cal.)", "Alabama-Birmingham", "St. Peter's", "Longwood", "Loyola (Ill.)"]

# x denotes the number of games played in 2022
# y denotes the number of games not played in 2022
# z denotes the number of games played from 1985 - 2022
# x should be greater than 1, and x + y = z
for p in w:
    x = df_2022[(df_2022["WTEAM"] == p)
                | (df_2022["LTEAM"] == p)]
    y = df_not_2022[(df_not_2022["WTEAM"] == p)
                    | (df_not_2022["LTEAM"] == p)]
    z = df[(df["WTEAM"] == p)
           | (df["LTEAM"] == p)]

    print(p)
    print("Games played in 2022:", len(x), len(x) > 0)
    print("Games not played in 2022:", len(y))
    print(F"Should be {len(x)} + {len(y)} = {len(z)}",
          len(x) + len(y) == len(z))
    print("\n")
