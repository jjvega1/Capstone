from urllib.request import urlopen as uReq
from bs4 import BeautifulSoup as soup
import pandas as pd

# We wil get the 2023 March Madness results the same way
# we did with the 2022 results, but with a different URL.
# There are a few differences, but mostly the process is the same.
url_2023 = "https://www.ncaa.com/news/basketball-men/mml-official-bracket/2023-04-04/latest-bracket-schedule-and-scores-2023-ncaa-mens-tournament"
uClient_2023 = uReq(url_2023)
page_html_2023 = uClient_2023.read()
uClient_2023.close()
page_soup_2023 = soup(page_html_2023, "html.parser")
cells = page_soup_2023.findAll("a", {"target": "_blank"})

'''
# Run this first to see where to start collecting data
for cell in range(len(cells)):
    print(cell, cells[cell].text)
'''

# How we change rounds
count = 0
round = 0

# For later
s = set({})

# This also has winners first
seeds = []
teams = []
scores = []
rounds = []

for i in range(14, 149):
    # There is a missing value where the seed is missing for one team.
    # This happens at the first game of the Round of 64
    # Since this is the only occurence, here is the only edgecase.
    # I will write in the data manually
    if i == 22:
        seeds.append((8, 9))
        teams.append(["Maryland", "West Virginia"])
        scores.append((67, 65))
        rounds.append(1)
        count += 1
    elif "No." not in cells[i].text:
        continue
    else:
        x = cells[i].text.split()
        seed1 = x[1]
        team1 = x[2]
        # If game went to OT, then the list would be altered slightly
        if x[-1] == "(OT)":
            z = 1
        else:
            z = 0
        for j in range(3, len(x)):
            if x[j][:len(x[j]) - 1].isnumeric():
                score1 = x[j][:len(x[j]) - 1]
                seed2 = x[j + 2]
                for k in range(3, j):
                    team1 = team1 + " " + x[k]
                team2 = x[j + 3]
                for l in range(j + 4, len(x) - 1 - z):
                    team2 = team2 + " " + x[l]
                break
        score2 = x[-1 - z]

        # For later
        s.add(team1)
        s.add(team2)

        # Append data to lists
        seeds.append((seed1, seed2))
        teams.append([team1, team2])
        scores.append((score1, score2))
        rounds.append(round)

        # Update count and round
        count += 1
        if count == 4:
            round += 1
        elif count == 36:
            round += 1
        elif count == 52:
            round += 1
        elif count == 60:
            round += 1
        elif count == 64:
            round += 1
        elif count == 66:
            round += 1
        elif count == 67:
            round += 1

# We need to keep the names consistent with the cleaned file
with open("march_madness_results.csv", "r") as file:
    lines = [line for line in file]

# Add all names that participated in March Madness
set_of_names = set({})
for m in lines:
    names = m.split(",")
    set_of_names.add(names[3])
    set_of_names.add(names[-2])

# Look at all the mismatched names or newcomers
for n in s:
    if n not in set_of_names:
        print(n)

# Ctrl + F (cmd + F for Mac) these names
'''
Furman (First time in the Big Dance in the 64-team era)
Kennesaw State (First time in the Big Dance)
VCU (Renamed to 'Virginia Commonwealth')
NC State (Renamed to 'North Carolina State')
Texas A&M CC (Renamed to 'Texas A&M-Corpus Christi')
UConn (Renamed to Connecticut)
SE Missouri State (Renamed to 'Southeast Missouri State')
FDU (Renamed to 'Fairleigh Dickinson')
Mississippi St. (Renamed to 'Mississippi State')
USC (Renamed to 'Southern California')
Pitt (Renamed to 'Pittsburgh')
Louisiana (Renamed to 'Louisiana-Lafayette')
Saint Mary's (Renamed to 'St. Mary's (Cal.)')
'''

# Go through the checks first
for o in range(len(scores)):
    for q in range(0, 2):
        if teams[o][q] == "VCU":
            teams[o][q] = "Virginia Commonwealth"
        elif teams[o][q] == "NC State":
            teams[o][q] = "North Carolina State"
        elif teams[o][q] == "Texas A&M CC":
            teams[o][q] = "Texas A&M-Corpus Christi"
        elif teams[o][q] == "UConn":
            teams[o][q] = "Connecticut"
        elif teams[o][q] == "SE Missouri State":
            teams[o][q] = "Southeast Missouri State"
        elif teams[o][q] == "FDU":
            teams[o][q] = "Fairleigh Dickinson"
        elif teams[o][q] == "Mississippi St.":
            teams[o][q] = "Mississippi State"
        elif teams[o][q] == "USC":
            teams[o][q] = "Southern California"
        elif teams[o][q] == "Pitt":
            teams[o][q] = "Pittsburgh"
        elif teams[o][q] == "Louisiana":
            teams[o][q] = "Louisiana-Lafayette"
        elif teams[o][q] == "Saint Mary's":
            teams[o][q] = "St. Mary's (Cal.)"

    # Finally we add to our data while renaming appropiately
    with open("march_madness_results.csv", "a") as file:
        # Finally write it into the file
        file.write(
            F"2023,{rounds[o]},{seeds[o][0]},{teams[o][0]},{scores[o][0]},{seeds[o][1]},{teams[o][1]},{scores[o][1]} \n")

# A quick test to see if it worked
df = pd.read_csv("march_madness_results.csv")
df_2023 = df[df["YEAR"] == 2023]
df_not_2023 = df[df["YEAR"] != 2023]

# List of name changes
w = ["Furman", "Kennesaw State", "Virginia Commonwealth", "North Carolina State", "Texas A&M-Corpus Christi", "Connecticut", "Southeast Missouri State",
     "Fairleigh Dickinson", "Mississippi State", "Southern California", "Pittsburgh", "Louisiana-Lafayette", "St. Mary's (Cal.)"]

# x denotes the number of games played in 2023
# y denotes the number of games not played in 2023
# z denotes the number of games played from 1985 - 2023
# x should be greater than 1, and x + y = z
for p in w:
    x = df_2023[(df_2023["WTEAM"] == p)
                | (df_2023["LTEAM"] == p)]
    y = df_not_2023[(df_not_2023["WTEAM"] == p)
                    | (df_not_2023["LTEAM"] == p)]
    z = df[(df["WTEAM"] == p)
           | (df["LTEAM"] == p)]

    print(p)
    print("Games played in 2023:", len(x), len(x) > 0)
    print("Games not played in 2023:", len(y))
    print(F"Should be {len(x)} + {len(y)} = {len(z)}",
          len(x) + len(y) == len(z))
    print("\n")
